import React from "react";
import { createRoot } from "react-dom/client";
import BaseballQuiz from "./baseball-quiz";
import "./styles.css";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <React.StrictMode>
    <BaseballQuiz />
  </React.StrictMode>
);
