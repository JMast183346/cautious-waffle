import React, { useState, useEffect } from 'react';
import { RefreshCw, Trophy, Star, CheckCircle, XCircle } from 'lucide-react';

const BaseballQuiz = () => {
  // All questions with multiple choice options
  const allQuestions = [
    { 
      q: "Runner on first, one out. Ground ball to shortstop. What's the priority play?", 
      correct: "Turn a double play: throw to second, then relay to first",
      options: [
        "Turn a double play: throw to second, then relay to first",
        "Throw directly to first base for the sure out",
        "Tag the runner going to second, then throw to first",
        "Check the runner, then throw to first base"
      ],
      category: "Force Play" 
    },
    { 
      q: "Bases loaded, no outs. Ground ball to third baseman. What's the best play?", 
      correct: "Step on third for force out, then throw home",
      options: [
        "Step on third for force out, then throw home",
        "Throw home immediately",
        "Start a 5-4-3 double play",
        "Tag the runner, then throw to first"
      ],
      category: "Force Play" 
    },
    { 
      q: "Runner on second only, ground ball to shortstop. Is there a force play at third?", 
      correct: "No, it must be a tag play",
      options: [
        "No, it must be a tag play",
        "Yes, the runner is forced to third",
        "Only if there are less than 2 outs",
        "Yes, but only on a ground ball"
      ],
      category: "Force Play" 
    },
    { 
      q: "Runners on first and third, one out. Ground ball to second baseman. What's the standard play?", 
      correct: "Turn the double play (4-6-3 or 4-3)",
      options: [
        "Turn the double play (4-6-3 or 4-3)",
        "Throw home to prevent the run",
        "Tag the runner, then throw to first",
        "Throw to third to get the lead runner"
      ],
      category: "Force Play" 
    },
    { 
      q: "Runner on first, two outs. Routine ground ball to first baseman near the bag. Should they throw to second?", 
      correct: "No, step on first base for the easier out",
      options: [
        "No, step on first base for the easier out",
        "Yes, get the lead runner at second",
        "Tag the runner, then step on first",
        "Throw to the pitcher covering first"
      ],
      category: "Force Play" 
    },
    { 
      q: "Runner on second, no outs. Single to right field. Runner tries to score. Where should the throw go?", 
      correct: "Home plate through the cutoff man",
      options: [
        "Home plate through the cutoff man",
        "Directly to home plate",
        "To third base to prevent advancement",
        "To second base to get the batter-runner"
      ],
      category: "Tag Play" 
    },
    { 
      q: "Runner on first attempts to steal second. The pitch is fouled off. What happens?", 
      correct: "Runner must return to first base",
      options: [
        "Runner must return to first base",
        "Runner is allowed to stay at second",
        "Runner is called out for leaving early",
        "Play continues, runner decides where to go"
      ],
      category: "Tag Play" 
    },
    { 
      q: "Runner on third, one out. Fly ball to medium-depth left field. What should the runner do?", 
      correct: "Tag up and attempt to score after the catch",
      options: [
        "Tag up and attempt to score after the catch",
        "Run immediately on contact",
        "Stay at third base",
        "Go halfway and read the catch"
      ],
      category: "Tag Play" 
    },
    { 
      q: "Runner on second, fly ball to shallow right field. Should the runner tag?", 
      correct: "No, go halfway and read the catch",
      options: [
        "No, go halfway and read the catch",
        "Yes, always tag on fly balls",
        "Run immediately on contact",
        "Stay at second base"
      ],
      category: "Tag Play" 
    },
    { 
      q: "Runner attempts to steal third. Catcher throws to third, but the ball goes into left field. Can the runner try to score?", 
      correct: "Yes, the ball is live",
      options: [
        "Yes, the ball is live",
        "No, the runner must stay at third",
        "Only if the umpire signals to advance",
        "No, it's a dead ball"
      ],
      category: "Tag Play" 
    },
    { 
      q: "Runners on first and second, one out. High pop fly to shortstop in shallow left field. What's the call?", 
      correct: "Infield fly, batter is out",
      options: [
        "Infield fly, batter is out",
        "Play continues normally",
        "Automatic double play",
        "Runners must advance"
      ],
      category: "Infield Fly" 
    },
    { 
      q: "When does the infield fly rule apply?", 
      correct: "Runners on 1st & 2nd OR bases loaded, less than 2 outs",
      options: [
        "Runners on 1st & 2nd OR bases loaded, less than 2 outs",
        "Any time there's a runner in scoring position",
        "Only with bases loaded",
        "Whenever there are runners on base"
      ],
      category: "Infield Fly" 
    },
    { 
      q: "Runner on first only, no outs. Pop fly to second baseman. Is this an infield fly?", 
      correct: "No, need runners on at least 1st and 2nd",
      options: [
        "No, need runners on at least 1st and 2nd",
        "Yes, runner on first is enough",
        "Only if it's in the infield",
        "Yes, with less than 2 outs"
      ],
      category: "Infield Fly" 
    },
    { 
      q: "Infield fly is called, but the fielder drops the ball. What happens?", 
      correct: "Batter is still out, runners may advance at risk",
      options: [
        "Batter is still out, runners may advance at risk",
        "Everyone is safe, play continues",
        "Automatic double play",
        "Batter gets to run, foul ball"
      ],
      category: "Infield Fly" 
    },
    { 
      q: "Infield fly is hit in foul territory. The fielder drops it. What's the ruling?", 
      correct: "Simply a foul ball",
      options: [
        "Simply a foul ball",
        "Infield fly still applies, batter is out",
        "All runners advance one base",
        "Play continues, ball is live"
      ],
      category: "Infield Fly" 
    },
    { 
      q: "Pitcher begins his motion to home but stops midway. What's the call?", 
      correct: "Balk - runners advance one base",
      options: [
        "Balk - runners advance one base",
        "Illegal pitch - add a ball to the count",
        "Play continues normally",
        "Pitcher is ejected"
      ],
      category: "Balk" 
    },
    { 
      q: "Runner on first. Pitcher moves his shoulder toward first without stepping off the rubber first. What's the call?", 
      correct: "Balk - runner advances",
      options: [
        "Balk - runner advances",
        "Legal pickoff move",
        "Illegal pitch",
        "Umpire's discretion"
      ],
      category: "Balk" 
    },
    { 
      q: "Pitcher makes a pickoff throw to an unoccupied base. Is this a balk?", 
      correct: "Yes, unless a runner is attempting to advance there",
      options: [
        "Yes, unless a runner is attempting to advance there",
        "No, it's always legal",
        "Only if done more than once",
        "Yes, always a balk"
      ],
      category: "Balk" 
    },
    { 
      q: "From the stretch, the pitcher forgets to come to a complete stop before delivering. What's the call?", 
      correct: "Balk - runners advance one base",
      options: [
        "Balk - runners advance one base",
        "Illegal pitch - ball added to count",
        "Warning from umpire",
        "Play continues"
      ],
      category: "Balk" 
    },
    { 
      q: "Pitcher drops the ball while on the rubber with a runner on base. What happens?", 
      correct: "Balk - runners advance one base",
      options: [
        "Balk - runners advance one base",
        "Dead ball, no penalty",
        "Ball added to count",
        "Runner is out for interference"
      ],
      category: "Balk" 
    },
    { 
      q: "Runner on second, no outs. Batter hits a ground ball to shortstop. What should the runner do?", 
      correct: "Freeze to see if ball gets through, don't get doubled off",
      options: [
        "Freeze to see if ball gets through, don't get doubled off",
        "Always advance to third",
        "Run back to second immediately",
        "Take off for third on contact"
      ],
      category: "Baserunning" 
    },
    { 
      q: "Runner on third, one out. Ground ball hit to the drawn-in infield. What should the runner do?", 
      correct: "Read the ball - if hard, hold; if soft, break home",
      options: [
        "Read the ball - if hard, hold; if soft, break home",
        "Always break for home",
        "Always stay at third",
        "Wait for coach's signal"
      ],
      category: "Baserunning" 
    },
    { 
      q: "Runner on first, two outs, full count. The pitch is delivered. What should the runner do?", 
      correct: "Run on the pitch",
      options: [
        "Run on the pitch",
        "Wait to see if it's a hit",
        "Stay at first base",
        "Only run if it's a ball"
      ],
      category: "Baserunning" 
    },
    { 
      q: "Runner on first, no outs. Line drive hit directly at shortstop. What should the runner do?", 
      correct: "Freeze and get back to first immediately",
      options: [
        "Freeze and get back to first immediately",
        "Continue running to second",
        "Dive back to first",
        "Run to second then return"
      ],
      category: "Baserunning" 
    },
    { 
      q: "Tie game, bottom of the 9th, runner on third, no outs. What's the batter's approach?", 
      correct: "Put ball in play - sac fly or ground ball scores the run",
      options: [
        "Put ball in play - sac fly or ground ball scores the run",
        "Swing for a home run",
        "Take pitches and draw a walk",
        "Bunt the runner home"
      ],
      category: "Baserunning" 
    },
    { 
      q: "Runner on first, no outs. Sacrifice bunt sign is on. Where should the batter bunt?", 
      correct: "Down the first-base line",
      options: [
        "Down the first-base line",
        "Down the third-base line",
        "Back to the pitcher",
        "Anywhere in fair territory"
      ],
      category: "Sacrifice Bunt" 
    },
    { 
      q: "Runner on second, no outs. Sacrifice bunt is on. Where should the batter bunt?", 
      correct: "Down the third-base line",
      options: [
        "Down the third-base line",
        "Down the first-base line",
        "Back to the pitcher",
        "Pop it up to the infield"
      ],
      category: "Sacrifice Bunt" 
    },
    { 
      q: "Runners on first and second, no outs. Bunt goes to pitcher who fields it cleanly. Best play?", 
      correct: "Throw to third if runner hesitated, otherwise first",
      options: [
        "Throw to third if runner hesitated, otherwise first",
        "Always throw to first",
        "Always throw to third",
        "Throw to second for force out"
      ],
      category: "Sacrifice Bunt" 
    },
    { 
      q: "Runner on second, no outs, batter squares to bunt but pitch is high. What should batter do?", 
      correct: "Pull back and take the pitch",
      options: [
        "Pull back and take the pitch",
        "Bunt it anyway",
        "Swing away",
        "Fake bunt and swing"
      ],
      category: "Sacrifice Bunt" 
    },
    { 
      q: "Pitcher covers first on a bunt. First baseman throws wide. What base should pitcher be touching?", 
      correct: "Inside of the bag (foul-territory side)",
      options: [
        "Inside of the bag (foul-territory side)",
        "Outside of the bag (fair-territory side)",
        "Top of the bag",
        "Either side is fine"
      ],
      category: "Sacrifice Bunt" 
    },
    { 
      q: "Runner on third, one out. Safety squeeze is on. When does the runner break for home?", 
      correct: "After the batter makes contact",
      options: [
        "After the batter makes contact",
        "As pitcher begins delivery",
        "After the pitch is halfway to plate",
        "When catcher sets up"
      ],
      category: "Squeeze Play" 
    },
    { 
      q: "Runner on third, one out. Suicide squeeze is on. When does the runner break?", 
      correct: "As the pitcher begins delivery",
      options: [
        "As the pitcher begins delivery",
        "After batter makes contact",
        "When ball crosses the plate",
        "After catcher receives ball"
      ],
      category: "Squeeze Play" 
    },
    { 
      q: "Suicide squeeze is on, but the batter misses the bunt. What typically happens?", 
      correct: "Runner is usually out at home",
      options: [
        "Runner is usually out at home",
        "Runner is safe automatically",
        "Batter is called out",
        "Umpire calls time"
      ],
      category: "Squeeze Play" 
    },
    { 
      q: "Defense recognizes a squeeze play. What's the best defensive response?", 
      correct: "Pitch out - ball high and away",
      options: [
        "Pitch out - ball high and away",
        "Throw a strike down the middle",
        "Throw at the batter",
        "Step off the rubber"
      ],
      category: "Squeeze Play" 
    },
    { 
      q: "Squeeze bunt is popped up to the pitcher. What should runner on third do?", 
      correct: "Scramble back to third immediately",
      options: [
        "Scramble back to third immediately",
        "Continue running home",
        "Freeze and wait",
        "Dive back to third"
      ],
      category: "Squeeze Play" 
    },
    { 
      q: "Runner on first, one out. Good base stealer. When is the best count to steal?", 
      correct: "Behind in count like 2-0 or 3-1 (fastball likely)",
      options: [
        "Behind in count like 2-0 or 3-1 (fastball likely)",
        "0-2 count",
        "3-0 count",
        "Any count is the same"
      ],
      category: "Steal" 
    },
    { 
      q: "Runners on first and third, one out. Runner breaks from first. What's defense's play?", 
      correct: "Throw to second, check runner at third",
      options: [
        "Throw to second, check runner at third",
        "Throw home immediately",
        "Let him have second",
        "Fake throw to second, throw home"
      ],
      category: "Steal" 
    },
    { 
      q: "Runner on second attempts to steal third. Catcher's throw is offline. What should third baseman do?", 
      correct: "Catch and apply sweep tag, or let SS back up",
      options: [
        "Catch and apply sweep tag, or let SS back up",
        "Always try to catch it",
        "Let it go into left field",
        "Call timeout"
      ],
      category: "Steal" 
    },
    { 
      q: "Runner on first, delayed steal. When does the runner break?", 
      correct: "As catcher returns ball to pitcher",
      options: [
        "As catcher returns ball to pitcher",
        "As soon as pitch is thrown",
        "After pitch crosses the plate",
        "When pitcher catches the return throw"
      ],
      category: "Steal" 
    },
    { 
      q: "With a left-handed pitcher, what's the best technique for stealing second?", 
      correct: "Read the front leg - toward first is pickoff, toward home is pitch",
      options: [
        "Read the front leg - toward first is pickoff, toward home is pitch",
        "Always go on first move",
        "Wait for the ball to be released",
        "Watch the pitcher's eyes"
      ],
      category: "Steal" 
    },
    { 
      q: "What is the primary goal of the hit and run?", 
      correct: "Runner breaks, batter makes contact to advance runner",
      options: [
        "Runner breaks, batter makes contact to advance runner",
        "Batter swings for home run",
        "Runner steals, batter takes pitch",
        "Both batter and runner try to advance"
      ],
      category: "Hit and Run" 
    },
    { 
      q: "Hit and run is on, pitch is in the dirt. What should the batter do?", 
      correct: "Swing anyway to protect the runner",
      options: [
        "Swing anyway to protect the runner",
        "Take the pitch",
        "Bunt the ball",
        "Call timeout"
      ],
      category: "Hit and Run" 
    },
    { 
      q: "4-6-3 double play: Who is involved?", 
      correct: "Second baseman to shortstop to first baseman",
      options: [
        "Second baseman to shortstop to first baseman",
        "Shortstop to second baseman to first baseman",
        "Pitcher to shortstop to first baseman",
        "Second baseman to first baseman to third baseman"
      ],
      category: "Double Play" 
    },
    { 
      q: "6-4-3 double play: Who is involved?", 
      correct: "Shortstop to second baseman to first baseman",
      options: [
        "Shortstop to second baseman to first baseman",
        "Second baseman to shortstop to first baseman",
        "Shortstop to pitcher to first baseman",
        "Third baseman to second baseman to first baseman"
      ],
      category: "Double Play" 
    },
    { 
      q: "Runner on first, ground ball up the middle. Who covers second base?", 
      correct: "Shortstop if ball to right, 2B if ball to left",
      options: [
        "Shortstop if ball to right, 2B if ball to left",
        "Always the shortstop",
        "Always the second baseman",
        "Whoever is closest"
      ],
      category: "Double Play" 
    },
    { 
      q: "Runner on second, single to center field. Where does the cutoff man position?", 
      correct: "Shortstop between outfielder and home, lined up by catcher",
      options: [
        "Shortstop between outfielder and home, lined up by catcher",
        "Second baseman at second base",
        "First baseman near pitcher's mound",
        "Third baseman on the infield grass"
      ],
      category: "Cutoff" 
    },
    { 
      q: "The outfielder's throw is offline. What should the cutoff man do?", 
      correct: "Cut the ball and prevent extra bases",
      options: [
        "Cut the ball and prevent extra bases",
        "Let it go through to the base",
        "Throw it back to the pitcher",
        "Always let the catcher get it"
      ],
      category: "Cutoff" 
    },
    { 
      q: "Shallow fly ball between shortstop and left fielder. Who has priority?", 
      correct: "Outfielder - they're coming in with better view",
      options: [
        "Outfielder - they're coming in with better view",
        "Shortstop - they called it first",
        "Whoever is closer",
        "The team captain decides"
      ],
      category: "Fly Ball" 
    },
    { 
      q: "Fly ball between two outfielders. Who has priority?", 
      correct: "Center fielder over corner outfielders",
      options: [
        "Center fielder over corner outfielders",
        "Left fielder always",
        "Right fielder always",
        "Whoever calls it first"
      ],
      category: "Fly Ball" 
    },
    { 
      q: "Runner caught between first and second. What's the ideal execution?", 
      correct: "Get runner going to first, throw early, minimal throws",
      options: [
        "Get runner going to first, throw early, minimal throws",
        "Chase runner to second base",
        "Throw ball back and forth many times",
        "Let runner choose direction"
      ],
      category: "Rundown" 
    },
    { 
      q: "Runner caught between third and home. Priority for the defense?", 
      correct: "Do not let the run score - chase back to third",
      options: [
        "Do not let the run score - chase back to third",
        "Tag the runner out anywhere",
        "Get the easy out going home",
        "Throw to first base"
      ],
      category: "Rundown" 
    },
    { 
      q: "What's the maximum number of throws a rundown should ideally take?", 
      correct: "Two throws maximum",
      options: [
        "Two throws maximum",
        "As many as needed",
        "One throw only",
        "At least three throws"
      ],
      category: "Rundown" 
    },
    { 
      q: "Runner on third, wild pitch in the dirt. When should the runner break?", 
      correct: "As soon as ball is past catcher toward backstop",
      options: [
        "As soon as ball is past catcher toward backstop",
        "Wait for coach's signal",
        "When catcher stands up",
        "After umpire makes call"
      ],
      category: "Wild Pitch" 
    },
    { 
      q: "With two strikes, third strike is in the dirt. What must the batter do?", 
      correct: "Run to first if first is unoccupied or 2 outs",
      options: [
        "Run to first if first is unoccupied or 2 outs",
        "Always run to first",
        "Never run, you're automatically out",
        "Ask the umpire"
      ],
      category: "Wild Pitch" 
    },
    { 
      q: "Dropped third strike, runner on first with one out. Is the batter out?", 
      correct: "Yes - with first occupied and less than 2 outs",
      options: [
        "Yes - with first occupied and less than 2 outs",
        "No, batter can run to first",
        "Only if catcher tags him",
        "Umpire decides"
      ],
      category: "Wild Pitch" 
    },
    { 
      q: "Runner hits the shortstop who is not fielding the ball. What's the call?", 
      correct: "Obstruction - runner awarded at least second base",
      options: [
        "Obstruction - runner awarded at least second base",
        "Runner is out for interference",
        "Play continues normally",
        "Dead ball, runners return"
      ],
      category: "Interference" 
    },
    { 
      q: "Batter hits a ground ball that strikes the runner between first and second. What happens?", 
      correct: "Runner is out for interference, batter to first",
      options: [
        "Runner is out for interference, batter to first",
        "Batter is out",
        "Play continues",
        "Both are out"
      ],
      category: "Interference" 
    },
    { 
      q: "Runner misses second base but scores. What must the defense do?", 
      correct: "Appeal at second base before next pitch",
      options: [
        "Appeal at second base before next pitch",
        "Appeal at home plate",
        "Tell the umpire immediately",
        "Nothing, run counts"
      ],
      category: "Appeal" 
    },
    { 
      q: "0-2 count. What should the pitcher throw?", 
      correct: "Waste pitch out of zone - breaking ball or high fastball",
      options: [
        "Waste pitch out of zone - breaking ball or high fastball",
        "Fastball down the middle",
        "Another strike",
        "Intentional ball"
      ],
      category: "Count Strategy" 
    },
    { 
      q: "3-0 count with a runner on first. What does the batter usually do?", 
      correct: "Take the pitch unless given green light",
      options: [
        "Take the pitch unless given green light",
        "Always swing away",
        "Bunt the runner over",
        "Hit and run"
      ],
      category: "Count Strategy" 
    },
    { 
      q: "3-2 count, two outs, runner on first. What should the runner do?", 
      correct: "Run on the pitch",
      options: [
        "Run on the pitch",
        "Stay at first",
        "Lead off normally",
        "Wait to see if it's a hit"
      ],
      category: "Count Strategy" 
    },
    { 
      q: "Tie game, bottom 9th, runner on third, one out. Where should the infield play?", 
      correct: "Infield in - prevent the run from scoring",
      options: [
        "Infield in - prevent the run from scoring",
        "Normal depth",
        "Double play depth",
        "Outfield shifts in"
      ],
      category: "Defense" 
    },
    { 
      q: "Up by 3 runs in the 7th, runners on first and second, no outs. How should infield play?", 
      correct: "Normal or double-play depth",
      options: [
        "Normal or double-play depth",
        "Infield in",
        "Corners in, middle back",
        "All the way back"
      ],
      category: "Defense" 
    },
    { 
      q: "Fly ball hits the foul pole above the fence. What's the ruling?", 
      correct: "Home run - foul poles are in fair territory",
      options: [
        "Home run - foul poles are in fair territory",
        "Foul ball",
        "Ground rule double",
        "Umpire's discretion"
      ],
      category: "Rules" 
    },
    { 
      q: "Ball stuck in the outfield fence. What's the ruling?", 
      correct: "Ground-rule double - runners advance 2 bases",
      options: [
        "Ground-rule double - runners advance 2 bases",
        "Home run",
        "Triple",
        "Single and runners advance 1 base"
      ],
      category: "Rules" 
    },
    { 
      q: "Fan reaches over fence and catches potential home run. Ruling?", 
      correct: "Home run is awarded",
      options: [
        "Home run is awarded",
        "Fan interference, batter is out",
        "Ground rule double",
        "Replay the pitch"
      ],
      category: "Rules" 
    },
    { 
      q: "Bases loaded, no outs. What's the pitcher's goal?", 
      correct: "Ground ball for double play or strikeout",
      options: [
        "Ground ball for double play or strikeout",
        "Fly ball to outfield",
        "Walk the batter",
        "Pitch around the hitter"
      ],
      category: "Pitching" 
    },
    { 
      q: "Ground ball down the line. What determines fair or foul?", 
      correct: "Where ball is when it passes 1st/3rd base",
      options: [
        "Where ball is when it passes 1st/3rd base",
        "Where it first lands",
        "Where it stops rolling",
        "Umpire's judgment call"
      ],
      category: "Rules" 
    },
    { 
      q: "Can a pitcher fake a throw to first base from the rubber?", 
      correct: "Yes, since 2013 rule change",
      options: [
        "Yes, since 2013 rule change",
        "No, always a balk",
        "Only with no runners on base",
        "Only in youth baseball"
      ],
      category: "Rules" 
    },
    { 
      q: "A fair batted ball bounces over the outfield fence. What's the ruling?", 
      correct: "Ground-rule double",
      options: [
        "Ground-rule double",
        "Home run",
        "Triple",
        "In play, keep running"
      ],
      category: "Rules" 
    },
    { 
      q: "Can a batter switch boxes during an at-bat?", 
      correct: "Yes, when pitcher not in set position or windup",
      options: [
        "Yes, when pitcher not in set position or windup",
        "No, never allowed",
        "Only between pitches",
        "Only with umpire permission"
      ],
      category: "Rules" 
    },
    { 
      q: "What happens if a pitch hits the batter's bat and then hits the batter?", 
      correct: "Foul ball",
      options: [
        "Foul ball",
        "Hit by pitch, batter takes first",
        "Strike on the batter",
        "Dead ball, replay pitch"
      ],
      category: "Rules" 
    },
    { 
      q: "Can a team use more than 9 players defensively?", 
      correct: "No, only 9 players allowed on field",
      options: [
        "No, only 9 players allowed on field",
        "Yes, 10 is allowed",
        "Yes, up to 11 in youth baseball",
        "Umpire decides based on league"
      ],
      category: "Rules" 
    },
    { 
      q: "A fielder throws his glove at a batted ball and makes contact. What happens?", 
      correct: "Batter is awarded three bases (triple)",
      options: [
        "Batter is awarded three bases (triple)",
        "Batter is awarded home run",
        "Batter is out",
        "Play continues normally"
      ],
      category: "Rules" 
    }
  ];

  const [quizQuestions, setQuizQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);

  // Initialize quiz with 10 random questions
  const startNewQuiz = () => {
    const shuffled = [...allQuestions].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, 10).map(q => ({
      ...q,
      shuffledOptions: [...q.options].sort(() => Math.random() - 0.5)
    }));
    setQuizQuestions(selected);
    setCurrentQuestion(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setQuizComplete(false);
  };

  useEffect(() => {
    startNewQuiz();
  }, []);

  const handleAnswerClick = (answer) => {
    if (showResult) return; // Prevent multiple clicks
    
    setSelectedAnswer(answer);
    setShowResult(true);
    
    const isCorrect = answer === quizQuestions[currentQuestion].correct;
    if (isCorrect) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < 9) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizComplete(true);
    }
  };

  // Baseball diamond SVG component
  const BaseballDiamond = ({ basesFilled }) => (
    <svg viewBox="0 0 200 200" className="w-48 h-48 mx-auto">
      {/* Outfield grass */}
      <circle cx="100" cy="165" r="90" fill="#2d5016" opacity="0.3"/>
      
      {/* Infield dirt */}
      <path d="M 100 165 L 35 100 L 100 35 L 165 100 Z" fill="#8b5a2b" opacity="0.4"/>
      
      {/* Grass infield */}
      <path d="M 100 165 L 65 130 L 100 95 L 135 130 Z" fill="#4a7c2e"/>
      
      {/* Pitcher's mound */}
      <circle cx="100" cy="130" r="8" fill="#8b5a2b"/>
      <circle cx="100" cy="130" r="4" fill="#d4a574"/>
      
      {/* Bases */}
      {/* Home plate */}
      <polygon points="100,165 95,160 95,155 105,155 105,160" fill="white" stroke="#333" strokeWidth="1"/>
      
      {/* First base */}
      <rect x="155" y="90" width="10" height="10" fill={basesFilled >= 1 ? "#fbbf24" : "white"} 
            stroke="#333" strokeWidth="1" className="transition-all duration-300"/>
      
      {/* Second base */}
      <rect x="95" y="30" width="10" height="10" fill={basesFilled >= 2 ? "#fbbf24" : "white"} 
            stroke="#333" strokeWidth="1" transform="rotate(45 100 35)" className="transition-all duration-300"/>
      
      {/* Third base */}
      <rect x="30" y="90" width="10" height="10" fill={basesFilled >= 3 ? "#fbbf24" : "white"} 
            stroke="#333" strokeWidth="1" className="transition-all duration-300"/>
      
      {/* Baseline paths */}
      <line x1="100" y1="165" x2="165" y2="100" stroke="#d4a574" strokeWidth="2" opacity="0.5"/>
      <line x1="165" y1="100" x2="100" y2="35" stroke="#d4a574" strokeWidth="2" opacity="0.5"/>
      <line x1="100" y1="35" x2="35" y2="100" stroke="#d4a574" strokeWidth="2" opacity="0.5"/>
      <line x1="35" y1="100" x2="100" y2="165" stroke="#d4a574" strokeWidth="2" opacity="0.5"/>
    </svg>
  );

  if (quizQuestions.length === 0) {
    return <div className="flex items-center justify-center min-h-screen bg-green-100">
      <div className="text-2xl">Loading quiz...</div>
    </div>;
  }

  const currentQ = quizQuestions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-100 to-blue-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="text-6xl">⚾</div>
            <h1 className="text-5xl font-bold text-red-700" style={{textShadow: '2px 2px 4px rgba(0,0,0,0.2)'}}>
              Baseball IQ Challenge
            </h1>
            <div className="text-6xl">⚾</div>
          </div>
          <p className="text-xl text-gray-700 font-semibold">Master Situational Baseball!</p>
        </div>

        {!quizComplete ? (
          <div className="bg-white rounded-3xl shadow-2xl p-8 border-4 border-red-600">
            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-lg font-bold text-gray-700">
                  Question {currentQuestion + 1} of 10
                </span>
                <span className="text-lg font-bold text-green-600">
                  Score: {score}/{currentQuestion + (showResult ? 1 : 0)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden border-2 border-gray-400">
                <div 
                  className="bg-gradient-to-r from-red-500 to-red-600 h-full transition-all duration-500 flex items-center justify-end pr-2"
                  style={{ width: `${((currentQuestion + 1) / 10) * 100}%` }}
                >
                  <span className="text-white text-xs font-bold">
                    {Math.round(((currentQuestion + 1) / 10) * 100)}%
                  </span>
                </div>
              </div>
            </div>

            {/* Baseball Diamond */}
            <div className="mb-6">
              <BaseballDiamond basesFilled={Math.min(score, 3)} />
            </div>

            {/* Category Badge */}
            <div className="text-center mb-4">
              <span className="inline-block bg-blue-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                {currentQ.category}
              </span>
            </div>

            {/* Question */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-6 mb-6 border-3 border-blue-300 shadow-inner">
              <p className="text-2xl font-bold text-gray-800 text-center leading-relaxed">
                {currentQ.q}
              </p>
            </div>

            {/* Multiple Choice Options */}
            <div className="space-y-4">
              {currentQ.shuffledOptions.map((option, index) => {
                const isCorrect = option === currentQ.correct;
                const isSelected = option === selectedAnswer;
                
                let buttonClass = "w-full p-5 rounded-xl text-left font-semibold text-lg transition-all duration-200 border-4 ";
                
                if (!showResult) {
                  buttonClass += "bg-white hover:bg-blue-50 border-blue-300 hover:border-blue-500 hover:shadow-lg transform hover:scale-102";
                } else if (isCorrect) {
                  buttonClass += "bg-green-200 border-green-500 shadow-lg";
                } else if (isSelected && !isCorrect) {
                  buttonClass += "bg-red-200 border-red-500 shadow-lg";
                } else {
                  buttonClass += "bg-gray-100 border-gray-300 opacity-50";
                }

                return (
                  <button
                    key={index}
                    onClick={() => handleAnswerClick(option)}
                    disabled={showResult}
                    className={buttonClass}
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex-1 pr-4">{option}</span>
                      {showResult && isCorrect && (
                        <CheckCircle className="text-green-600 flex-shrink-0" size={28} />
                      )}
                      {showResult && isSelected && !isCorrect && (
                        <XCircle className="text-red-600 flex-shrink-0" size={28} />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Result Message */}
            {showResult && (
              <div className="mt-6 text-center space-y-4">
                {selectedAnswer === currentQ.correct ? (
                  <div className="bg-green-100 border-4 border-green-500 rounded-2xl p-6">
                    <p className="text-3xl font-bold text-green-700">⚾ Correct! Nice job! ⚾</p>
                  </div>
                ) : (
                  <div className="bg-red-100 border-4 border-red-500 rounded-2xl p-6">
                    <p className="text-3xl font-bold text-red-700 mb-2">Not quite!</p>
                    <p className="text-lg text-gray-700">The correct answer was highlighted in green!</p>
                  </div>
                )}
                
                <button
                  onClick={handleNextQuestion}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-10 rounded-full text-xl shadow-lg transform hover:scale-105 transition-all duration-200 border-4 border-blue-800"
                >
                  {currentQuestion < 9 ? "Next Question ➡️" : "See Results 🏆"}
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-3xl shadow-2xl p-8 text-center border-4 border-yellow-500">
            <div className="mb-6">
              <Trophy size={100} className="mx-auto text-yellow-500 animate-bounce" />
            </div>
            
            <h2 className="text-4xl font-bold mb-4 text-gray-800">Quiz Complete!</h2>
            
            <div className="mb-6">
              <BaseballDiamond basesFilled={3} />
            </div>

            <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-8 mb-6 border-3 border-yellow-400">
              <p className="text-6xl font-bold text-gray-800 mb-2">{score}/10</p>
              <p className="text-2xl font-semibold text-gray-700">
                {score === 10 && "🎉 PERFECT GAME! You're a Baseball Genius!"}
                {score >= 8 && score < 10 && "⭐ All-Star Performance! Great job!"}
                {score >= 6 && score < 8 && "👍 Solid Hit! Keep practicing!"}
                {score >= 4 && score < 6 && "💪 Good effort! Study more situations!"}
                {score < 4 && "📚 Keep learning! Practice makes perfect!"}
              </p>
            </div>

            {/* Stars based on score */}
            <div className="flex justify-center gap-4 mb-8">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  size={60}
                  className={i < Math.floor(score / 3.4) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
                />
              ))}
            </div>

            <button
              onClick={startNewQuiz}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-10 rounded-full text-2xl shadow-lg transform hover:scale-105 transition-all duration-200 flex items-center gap-3 mx-auto border-4 border-blue-800"
            >
              <RefreshCw size={32} />
              Play Again!
            </button>

            <p className="mt-6 text-gray-600 text-lg">
              Try again for a new set of 10 random questions!
            </p>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-8 text-gray-600">
          <p className="text-sm">
            75+ Baseball Situational Plays • Perfect for Youth Players
          </p>
        </div>
      </div>
    </div>
  );
};

export default BaseballQuiz;